create definer = root@localhost view v1 as
select `day0705`.`student`.`studentid`      AS `studentid`,
       `day0705`.`student`.`studentname`    AS `studentname`,
       `day0705`.`student`.`studentage`     AS `studentage`,
       `day0705`.`student`.`studentsex`     AS `studentsex`,
       `day0705`.`student`.`studentaddress` AS `studentaddress`,
       `day0705`.`student`.`classid`        AS `classid`
from `day0705`.`student`
where (`day0705`.`student`.`classid` = 6);

