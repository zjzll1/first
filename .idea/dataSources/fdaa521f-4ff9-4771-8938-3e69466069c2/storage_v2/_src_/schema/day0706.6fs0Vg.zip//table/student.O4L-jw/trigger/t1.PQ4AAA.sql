create definer = root@localhost trigger t1
    after update
    on student
    for each row
begin
	   insert into loggin values (concat(old.name,'被修改了'));
	end;

